<?php

namespace App;

use App\Observers\LoanApplicationObserver;
use App\Traits\Auditable;
use App\Traits\MultiTenantModelTrait;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use \DateTimeInterface;
use Faker\Provider\ar_SA\Payment;

class LoanApplication extends Model
{
    use SoftDeletes,Auditable;

    public $table = 'loan_applications';

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'loan_amount',
        'analyst_id',
        'cfo_id',
        'loan_term',
        'term_type',
        'created_at',
        'updated_at',
        'deleted_at',
        'created_by_id',
        'status_id',
        'interest',
        'total_amount',
        'weekly_pay',
        'gender',
        'income_type',
        'income_amount',
        'expenses',
        'loan_purpose',
        'customer_id'


    ];

    protected static function booted()
    {
        self::observe(LoanApplicationObserver::class);
    }

    protected function serializeDate(DateTimeInterface $date)
    {
        return $date->format('Y-m-d H:i:s');
    }

    public function status()
    {
        return $this->belongsTo(Status::class, 'status_id');
    }

    public function payments()
    {
        return $this->hasMany(Payments::class, 'loan_id');
    }


    public function customer()
    {
        return $this->belongsTo(CustomerApplication::class, 'customer_id');
    }
    
    public function analyst()
    {
        return $this->belongsTo(User::class, 'analyst_id');
    }

    public function cfo()
    {
        return $this->belongsTo(User::class, 'cfo_id');
    }

    public function created_by()
    {
        return $this->belongsTo(User::class, 'created_by_id');
    }

    public function comments()
    {
        return $this->hasMany(Comment::class);
    }

    public function logs()
    {
        return $this->morphMany(AuditLog::class, 'subject');
    }
}
