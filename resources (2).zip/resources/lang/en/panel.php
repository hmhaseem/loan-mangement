<?php

return [
    'site_title' => 'Loan Application',
];
